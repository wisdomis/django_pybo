from django.apps import AppConfig


class PyboConfig(AppConfig):
    name = 'pybo'
