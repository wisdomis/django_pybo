from .base import *

DEBUG = False

ALLOWED_HOSTS = ['3.38.13.240']

STATIC_ROOT = BASE_DIR / 'static/'
STATICFILES_DIRS = []